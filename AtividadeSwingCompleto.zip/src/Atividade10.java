import javax.swing.*;
import java.awt.event.*;

public class Atividade10 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Barra de Progresso");
        JProgressBar progressBar = new JProgressBar(0, 100);
        JButton carregarButton = new JButton("Carregar");

        JPanel panel = new JPanel();
        panel.add(progressBar);
        panel.add(carregarButton);

        carregarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Thread(() -> {
                    for(int i = 0; i <= 100; i++) {
                        progressBar.setValue(i);
                        try {
                            Thread.sleep(50);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                    JOptionPane.showMessageDialog(frame, "Processo concluído!");
                }).start();
            }
        });

        frame.add(panel);
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

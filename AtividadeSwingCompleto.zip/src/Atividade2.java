import javax.swing.*;
import java.awt.event.*;

public class Atividade2 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Botão com Mensagem");
        JButton button = new JButton("Clique aqui");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Botão clicado!");
            }
        });
        frame.add(button);
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

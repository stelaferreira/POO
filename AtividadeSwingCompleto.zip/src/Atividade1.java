import javax.swing.*;

public class Atividade1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Bem-vindo ao Swing");
        JLabel label = new JLabel("Olá, mundo gráfico!", SwingConstants.CENTER);
        frame.add(label);
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

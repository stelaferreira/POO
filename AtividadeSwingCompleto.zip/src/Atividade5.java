import javax.swing.*;
import java.awt.event.*;

public class Atividade5 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Seleção Única");
        JRadioButton rb1 = new JRadioButton("Informática");
        JRadioButton rb2 = new JRadioButton("Engenharia");
        JRadioButton rb3 = new JRadioButton("Administração");
        ButtonGroup group = new ButtonGroup();
        group.add(rb1);
        group.add(rb2);
        group.add(rb3);
        JButton button = new JButton("Confirmar");

        JPanel panel = new JPanel();
        panel.add(rb1);
        panel.add(rb2);
        panel.add(rb3);
        panel.add(button);

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String curso = "";
                if (rb1.isSelected()) curso = "Informática";
                else if (rb2.isSelected()) curso = "Engenharia";
                else if (rb3.isSelected()) curso = "Administração";
                JOptionPane.showMessageDialog(frame, "Curso selecionado: " + curso);
            }
        });

        frame.add(panel);
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

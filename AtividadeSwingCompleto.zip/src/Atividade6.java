import javax.swing.*;
import java.awt.event.*;

public class Atividade6 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Login");
        JTextField usuarioField = new JTextField(10);
        JPasswordField senhaField = new JPasswordField(10);
        JButton entrarButton = new JButton("Entrar");

        JPanel panel = new JPanel();
        panel.add(new JLabel("Usuário:"));
        panel.add(usuarioField);
        panel.add(new JLabel("Senha:"));
        panel.add(senhaField);
        panel.add(entrarButton);

        entrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String usuario = usuarioField.getText();
                String senha = new String(senhaField.getPassword());
                if(usuario.equals("admin") && senha.equals("1234")) {
                    JOptionPane.showMessageDialog(frame, "Login realizado com sucesso");
                } else {
                    JOptionPane.showMessageDialog(frame, "Usuário ou senha incorretos");
                }
            }
        });

        frame.add(panel);
        frame.setSize(300, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

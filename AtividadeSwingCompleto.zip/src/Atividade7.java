import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Atividade7 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Calculadora Básica");
        frame.setLayout(new GridLayout(3, 2));

        JTextField num1Field = new JTextField();
        JTextField num2Field = new JTextField();
        JButton somarButton = new JButton("Somar");
        JButton subtrairButton = new JButton("Subtrair");
        JLabel resultadoLabel = new JLabel("Resultado: ");

        frame.add(new JLabel("Número 1:"));
        frame.add(num1Field);
        frame.add(new JLabel("Número 2:"));
        frame.add(num2Field);
        frame.add(somarButton);
        frame.add(subtrairButton);
        frame.add(resultadoLabel);

        somarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int n1 = Integer.parseInt(num1Field.getText());
                    int n2 = Integer.parseInt(num2Field.getText());
                    resultadoLabel.setText("Resultado: " + (n1 + n2));
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Digite números válidos.");
                }
            }
        });

        subtrairButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int n1 = Integer.parseInt(num1Field.getText());
                    int n2 = Integer.parseInt(num2Field.getText());
                    resultadoLabel.setText("Resultado: " + (n1 - n2));
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Digite números válidos.");
                }
            }
        });

        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

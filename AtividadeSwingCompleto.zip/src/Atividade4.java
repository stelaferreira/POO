import javax.swing.*;
import java.awt.event.*;

public class Atividade4 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Escolha Múltipla");
        JCheckBox cb1 = new JCheckBox("Ler");
        JCheckBox cb2 = new JCheckBox("Esportes");
        JCheckBox cb3 = new JCheckBox("Música");
        JButton button = new JButton("Mostrar Seleção");

        JPanel panel = new JPanel();
        panel.add(cb1);
        panel.add(cb2);
        panel.add(cb3);
        panel.add(button);

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String msg = "Hobbies escolhidos: ";
                if (cb1.isSelected()) msg += "Ler ";
                if (cb2.isSelected()) msg += "Esportes ";
                if (cb3.isSelected()) msg += "Música ";
                JOptionPane.showMessageDialog(frame, msg);
            }
        });

        frame.add(panel);
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

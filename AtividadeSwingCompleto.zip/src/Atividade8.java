import javax.swing.*;
import java.awt.*;

public class Atividade8 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Cadastro com Abas");
        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel dadosPanel = new JPanel();
        JTextField nomeField = new JTextField(10);
        JTextField idadeField = new JTextField(5);
        dadosPanel.add(new JLabel("Nome:"));
        dadosPanel.add(nomeField);
        dadosPanel.add(new JLabel("Idade:"));
        dadosPanel.add(idadeField);

        JPanel enderecoPanel = new JPanel();
        JTextField ruaField = new JTextField(10);
        JTextField cidadeField = new JTextField(10);
        enderecoPanel.add(new JLabel("Rua:"));
        enderecoPanel.add(ruaField);
        enderecoPanel.add(new JLabel("Cidade:"));
        enderecoPanel.add(cidadeField);

        JPanel resumoPanel = new JPanel();
        JTextArea resumoArea = new JTextArea(5, 20);
        resumoPanel.add(new JScrollPane(resumoArea));

        JButton mostrarResumo = new JButton("Mostrar Resumo");
        mostrarResumo.addActionListener(e -> {
            String resumo = "Nome: " + nomeField.getText() + "\n" +
                            "Idade: " + idadeField.getText() + "\n" +
                            "Rua: " + ruaField.getText() + "\n" +
                            "Cidade: " + cidadeField.getText();
            resumoArea.setText(resumo);
        });
        resumoPanel.add(mostrarResumo);

        tabbedPane.add("Dados Pessoais", dadosPanel);
        tabbedPane.add("Endereço", enderecoPanel);
        tabbedPane.add("Resumo", resumoPanel);

        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

import javax.swing.*;
import java.awt.event.*;

public class Atividade3 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Entrada de Nome");
        JTextField textField = new JTextField(15);
        JButton button = new JButton("Confirmar");
        JLabel label = new JLabel("Digite seu nome: ");

        JPanel panel = new JPanel();
        panel.add(textField);
        panel.add(button);
        panel.add(label);

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                label.setText("Olá, " + textField.getText() + "!");
            }
        });

        frame.add(panel);
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
